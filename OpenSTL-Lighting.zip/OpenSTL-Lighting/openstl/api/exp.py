# Copyright (c) CAIRI AI Lab. All rights reserved

import sys
import time
import os.path as osp
from fvcore.nn import FlopCountAnalysis, flop_count_table

import torch

from openstl.methods import method_maps
from openstl.datasets import BaseDataModule
from openstl.utils import (get_dataset, measure_throughput, SetupCallback, EpochEndCallback, BestCheckpointCallback)

from lightning import seed_everything, Trainer
import lightning.pytorch.callbacks as lc


class BaseExperiment(object):
    """The basic class of PyTorch training and evaluation."""

    def __init__(self, args, dataloaders=None, strategy='auto'):
        """Initialize experiments (non-dist as an example)"""
        self.args = args
        self.config = self.args.__dict__
        self.method = None
        self.args.method = self.args.method.lower()
        self._dist = self.args.dist

        base_dir = args.res_dir if args.res_dir is not None else 'work_dirs'
        save_dir = osp.join(base_dir, args.ex_name if not args.ex_name.startswith(args.res_dir) \
            else args.ex_name.split(args.res_dir+'/')[-1])
        ckpt_dir = osp.join(save_dir, 'checkpoints')

        seed_everything(args.seed)
        self.data = self._get_data(dataloaders)
        self.method = method_maps[self.args.method](steps_per_epoch=len(self.data.train_loader), \
            test_mean=self.data.test_mean, test_std=self.data.test_std, save_dir=save_dir, **self.config)
        callbacks, self.save_dir = self._load_callbacks(args, save_dir, ckpt_dir)
        self.trainer = self._init_trainer(self.args, callbacks, strategy)

    def _init_trainer(self, args, callbacks, strategy):
        return Trainer(devices=args.gpus,  # Use these GPUs
                       max_epochs=args.epoch,  # Maximum number of epochs to train for
                       strategy=strategy,   # 'ddp', 'deepspeed_stage_2', 'ddp_find_unused_parameters_false'
                       accelerator='gpu',  # Use distributed data parallel
                       callbacks=callbacks
                    )

    def _load_callbacks(self, args, save_dir, ckpt_dir):
        method_info = None
        if self._dist == 0:
            if not self.args.no_display_method_info:
                method_info = self.display_method_info(args)

        setup_callback = SetupCallback(
            prefix = 'train' if (not args.test) else 'test',
            setup_time = time.strftime('%Y%m%d_%H%M%S', time.localtime()),
            save_dir = save_dir,
            ckpt_dir = ckpt_dir,
            args = args,
            method_info = method_info,
            argv_content = sys.argv + ["gpus: {}".format(torch.cuda.device_count())],
        )

        ckpt_callback = BestCheckpointCallback(
            monitor=args.metric_for_bestckpt,
            filename='best-{epoch:02d}-{val_loss:.3f}',
            mode='min',
            save_last=True,
            dirpath=ckpt_dir,
            verbose=True,
            every_n_epochs=args.log_step,
        )
        
        epochend_callback = EpochEndCallback()

        callbacks = [setup_callback, ckpt_callback, epochend_callback]
        if args.sched:
            callbacks.append(lc.LearningRateMonitor(logging_interval=None))
        return callbacks, save_dir

    def _get_data(self, dataloaders=None):
        """Prepare datasets and dataloaders"""
        if dataloaders is None:
            train_loader, vali_loader, test_loader = \
                get_dataset(self.args.dataname, self.config)
        else:
            train_loader, vali_loader, test_loader = dataloaders

        vali_loader = test_loader if vali_loader is None else vali_loader
        return BaseDataModule(train_loader, vali_loader, test_loader)

    def train(self):
        self.trainer.fit(self.method, self.data, ckpt_path=self.args.ckpt_path if self.args.ckpt_path else None)

    # def test(self):
    #     if self.args.test == True:
    #         ckpt = torch.load(osp.join(self.save_dir, 'checkpoints', 'best.ckpt'))
    #         self.method.load_state_dict(ckpt['state_dict'])
    #     self.trainer.test(self.method, self.data)
    def test(self):
        if self.args.test == True:
            # 1. 优先使用用户指定的 ckpt_path
            load_path = self.args.ckpt_path if self.args.ckpt_path else osp.join(self.save_dir, 'checkpoints',
                                                                                 'best.ckpt')
            print(f"💡 [系统级修改] 正在读取权重: {load_path}")
            import torch
            ckpt = torch.load(load_path, map_location='cpu')

            if 'state_dict' in ckpt:
                self.method.load_state_dict(ckpt['state_dict'])
            else:
                try:
                    self.method.load_state_dict(ckpt)
                except RuntimeError:
                    self.method.model.load_state_dict(ckpt)

            # 2. 强开天气指标门禁
            print('💡 [系统级修改] 已强制激活 CIKM 的气象评估通道 (CSI/HSS/POD)！')
            self.method.metric_list = ['mse', 'mae', 'rmse', 'pod', 'csi', 'hss']
            self.method.spatial_norm = True
            # self.method.threshold = [0.1, 0.3, 0.5]  # 根据你需要设置降水阈值
            self.method.threshold = [0.5 / 255.0, 2.0 / 255.0, 5.0 / 255.0, 10.0 / 255.0,
                                     30.0 / 255.0]  # 对齐顶会论文的常用降雨强度梯度
            self.method.dataname = 'weather_cikm'  # 骗过底层让它以为是天气数据

            # 3. 釜底抽薪：关掉会导致崩溃的 logger
            print('💡 [系统级修改] 已关闭底层 Logger，彻底根除 YAML 历史报错！')
            if hasattr(self.trainer, 'loggers'):
                self.trainer.loggers = []
            self.trainer.logger = None

        # 4. 拿到最纯净的结果（因为关闭了 Logger，所以绝对不会崩溃）
        results = self.trainer.test(self.method, self.data)

        # 5. 打印并保存
        if self.args.test == True:
            print("\n" + "🌟" * 25)
            print("        最终模型评估成绩单")
            print("🌟" * 25)
            save_path = "test_metrics_result.txt"
            with open(save_path, "w", encoding="utf-8") as f:
                f.write("=== CIKM 模型评估成绩单 ===\n")
                if results and len(results) > 0:
                    for k, v in results[0].items():
                        print(f" 👉 {k}: {v}")
                        f.write(f"{k}: {v}\n")
                else:
                    print(" ⚠️ 暂未捕获到指标，可能是底层屏蔽了返回。")
            print("🌟" * 25)
            print(f"📁 成绩单也已同步保存至: {save_path}\n")
    
    def display_method_info(self, args):
        """Plot the basic infomation of supported methods"""
        device = torch.device(args.device)
        if args.device == 'cuda':
            assign_gpu = 'cuda:' + (str(args.gpus[0]) if len(args.gpus) == 1 else '0')
            device = torch.device(assign_gpu)
        T, C, H, W = args.in_shape
        if args.method in ['simvp', 'tau', 'mmvp', 'wast','exprecast','stldm']:
            input_dummy = torch.ones(1, args.pre_seq_length, C, H, W).to(device)

            # 2. 紧接着在下面插入这三行，专门为 alphapre 造两个假数据 (x 和 y)
        elif args.method == 'alphapre':
            _tmp_input = torch.ones(1, args.pre_seq_length, C, H, W).to(device)
            _tmp_gt = torch.ones(1, args.aft_seq_length, C, H, W).to(device)
            input_dummy = (_tmp_input, _tmp_gt)

        elif args.method == 'phydnet':
            _tmp_input1 = torch.ones(1, args.pre_seq_length, C, H, W).to(device)
            _tmp_input2 = torch.ones(1, args.aft_seq_length, C, H, W).to(device)
            _tmp_constraints = torch.zeros((49, 7, 7)).to(device)
            input_dummy = (_tmp_input1, _tmp_input2, _tmp_constraints)
        elif args.method in ['convlstm', 'predrnnpp', 'predrnn', 'mim', 'e3dlstm', 'mau']:
            Hp, Wp = H // args.patch_size, W // args.patch_size
            Cp = args.patch_size ** 2 * C
            _tmp_input = torch.ones(1, args.total_length, Hp, Wp, Cp).to(device)
            _tmp_flag = torch.ones(1, args.aft_seq_length - 1, Hp, Wp, Cp).to(device)
            input_dummy = (_tmp_input, _tmp_flag)
        elif args.method in ['swinlstm_d', 'swinlstm_b']:
            input_dummy = torch.ones(1, self.args.total_length, H, W, C).to(device)
        elif args.method == 'predrnnv2':
            Hp, Wp = H // args.patch_size, W // args.patch_size
            Cp = args.patch_size ** 2 * C
            _tmp_input = torch.ones(1, args.total_length, Hp, Wp, Cp).to(device)
            _tmp_flag = torch.ones(1, args.total_length - 2, Hp, Wp, Cp).to(device)
            input_dummy = (_tmp_input, _tmp_flag)
        elif args.method == 'prednet':
           input_dummy = torch.ones(1, 1, C, H, W, requires_grad=True).to(device)
        else:
            raise ValueError(f'Invalid method name {args.method}')

        dash_line = '-' * 80 + '\n'
        info = self.method.model.__repr__()
        flops = FlopCountAnalysis(self.method.model.to(device), input_dummy)
        flops = flop_count_table(flops)
        if args.fps:
            fps = measure_throughput(self.method.model.to(device), input_dummy)
            fps = 'Throughputs of {}: {:.3f}\n'.format(args.method, fps)
        else:
            fps = ''
        return info, flops, fps, dash_line
