import torch
import torch.nn.functional as F
from .simvp import SimVP
from openstl.models import exPreCast_Model


class exPreCast(SimVP):
    r"""exPreCast Method

    继承自 SimVP 以复用其原生的 training_step (损失计算) 流程，
    但完全接管模型的构建，并重写前向传播过程以实现严格的帧数对齐。
    """

    def __init__(self, **args):
        # 仿照官方规范，透传初始化参数
        super().__init__(**args)

    def _build_model(self, **args):
        # 拦截模型构建，换成我们自己的模型
        return exPreCast_Model(**args)

    def forward(self, batch_x, batch_y=None, **kwargs):
        """
        重写前向传播
        增加 batch_y=None 接收 validation/test 时框架硬塞入的第三个位置参数
        """
        # 1. 纯净地调用我们的模型（模型内部的 time_extractor 会直接完成序列长度转换）
        pred_y = self.model(batch_x)

        # 2. 规范地获取超参数 (使用 Lightning 标准的 self.hparams)
        aft_seq_length = self.hparams.aft_seq_length

        # 3. 终极防御墙：严格修剪或填充到目标帧数
        if pred_y.shape[1] > aft_seq_length:
            # 砍掉多余的帧
            pred_y = pred_y[:, :aft_seq_length, ...].contiguous()
        elif pred_y.shape[1] < aft_seq_length:
            # 安全兜底：如果模型由于 bug 输出少了，用 0 补齐，防止 Loss 崩溃
            pad_len = aft_seq_length - pred_y.shape[1]
            pred_y = F.pad(pred_y, (0, 0, 0, 0, 0, 0, 0, pad_len))

        return pred_y