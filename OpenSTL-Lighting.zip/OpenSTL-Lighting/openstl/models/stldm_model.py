import os
import sys
import copy
import torch
import torch.nn as nn
import torch.nn.functional as F

# =====================================================================
# 🚨 终极路径 Hack (魔法指令) 🚨
# 保持在文件顶部，确保环境变量准备就绪
# =====================================================================
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)


class STLDM_Model(nn.Module):
    def __init__(self, **kwargs):
        super().__init__()

        # =====================================================================
        # 🚨 延迟导入 (Lazy Import) 解决循环导入报错 🚨
        # =====================================================================
        from stldm import n2n_setup
        from stldm.config import STLDM_HKO

        # 1. 动态获取当前数据集的通道数和帧数 (CIKM 是 4通道, 7进, 8出)
        in_shape = kwargs.get('in_shape', (7, 4, 112, 112))
        self.in_channels = in_shape[1]
        self.pre_seq_length = kwargs.get('pre_seq_length', 7)
        self.aft_seq_length = kwargs.get('aft_seq_length', 8)

        # 2. 深度拷贝官方配置，防止污染全局变量
        custom_config = copy.deepcopy(STLDM_HKO)

        # 3. 🔥 核心 Hack V2：全方位篡改官方的通道与帧数配置 🔥
        def update_config(d):
            for k, v in d.items():
                if isinstance(v, dict):
                    update_config(v)
                # 统一修改独立的通道参数
                elif k in ['in_channels', 'out_ch', 'out_channels', 'in_ch']:
                    if v == 1:
                        d[k] = self.in_channels
                # 统一修改输入的 shape (T, C, H, W)
                elif k == 'shape_in' and isinstance(v, (list, tuple)):
                    v_list = list(v)
                    if len(v_list) >= 4:
                        v_list[0] = self.pre_seq_length  # 强行对齐输入帧数 (7)
                        if v_list[1] == 1:
                            v_list[1] = self.in_channels  # 强行对齐通道数 (4)
                    d[k] = tuple(v_list) if isinstance(v, tuple) else v_list
                # 统一修改输出的 shape (T2, C2, H2, W2)
                elif k == 'shape_out' and isinstance(v, (list, tuple)):
                    v_list = list(v)
                    if len(v_list) >= 4:
                        v_list[0] = self.aft_seq_length  # 强行对齐输出帧数 (8)
                        if v_list[1] == 1:
                            v_list[1] = self.in_channels  # 强行对齐通道数 (4)
                    d[k] = tuple(v_list) if isinstance(v, tuple) else v_list

        update_config(custom_config)

        # 4. 用被我们全面调教过的配置去实例化官方模型！
        self.stldm_net = n2n_setup['3D'](custom_config)

    def _resize(self, tensor, target_size):
        """🌟 空间维度缩放适配器 (解决 112 与 128 的尺寸冲突)"""
        B, T, C, H, W = tensor.shape
        tensor = tensor.reshape(B * T, C, H, W)  # 展平时间维度
        tensor = F.interpolate(tensor, size=(target_size, target_size), mode='bilinear', align_corners=False)
        return tensor.view(B, T, C, target_size, target_size)

    def compute_loss(self, x, y):
        """
        暴露官方计算 Loss 的接口。
        扩散模型 UNet 往往要求 128x128 这种完美尺寸，我们强行放大再算。
        """
        if x.shape[-1] != 128:
            x = self._resize(x, 128)
            y = self._resize(y, 128)
        return self.stldm_net.compute_loss(x, y)

    def forward(self, x):
        """
        暴露官方的采样去噪 (Sampling) 接口。
        输入 112 -> 放大到 128 -> 去噪预测 -> 缩小回 112 交给框架。
        """
        orig_size = x.shape[-1]
        if orig_size != 128:
            x = self._resize(x, 128)

        y_pred, _ = self.stldm_net(x, include_mu=True)

        if orig_size != 128:
            y_pred = self._resize(y_pred, orig_size)

        return y_pred