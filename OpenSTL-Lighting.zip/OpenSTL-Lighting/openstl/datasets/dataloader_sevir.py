"""
Input generator for sevir (Modified for independent .npz files)
"""

import os
import os.path as osp
import glob
import numpy as np
import torch

from openstl.datasets.utils import create_loader
from torch.utils.data import Dataset

# Record dtypes for reading
DTYPES = {'vil': np.uint8, 'vis': np.int16, 'ir069': np.int16, 'ir107': np.int16, 'lght': np.int16}


class SEVIRDataset(Dataset):
    """
    Sequence class for generating batches from SEVIR (.npz format)
    """

    def __init__(self,
                 data_root='data/sevir/sevir_npz',  # 默认 npz 数据集根目录
                 split='train',  # 'train', 'val', 或 'test'
                 data_name='vil',
                 use_augment=False,
                 n_batch_per_epoch=None,
                 unwrap_time=False,
                 shuffle=False,
                 shuffle_seed=1,
                 output_type=np.float32,
                 normalize_x=None,
                 normalize_y=None,
                 ):

        self.data_root = data_root
        self.split = split
        self.data_name = data_name
        self.use_augment = use_augment
        self.n_batch_per_epoch = n_batch_per_epoch
        self.output_type = output_type
        self.normalize_x = normalize_x
        self.normalize_y = normalize_y

        # 官方提供的标准化参数 (均值和标准差)
        self.mean = 33.44
        self.std = 47.54

        # 扫描对应 split 文件夹下的所有 .npz 文件
        self.data_dir = osp.join(self.data_root, self.split)
        self.file_list = sorted(glob.glob(osp.join(self.data_dir, '*.npz')))

        if len(self.file_list) == 0:
            print(f"⚠️ 警告: 在 {self.data_dir} 目录下没有找到任何 .npz 文件！请检查路径。")
        else:
            print(f"✅ 成功加载 SEVIR {split} 集，共计 {len(self.file_list)} 个样本。")

    def __len__(self):
        """
        How many batches to generate per epoch
        """
        max_n = len(self.file_list)
        if self.n_batch_per_epoch is not None:
            return min(self.n_batch_per_epoch, max_n)
        else:
            return max_n

    def _augment_seq(self, X, Y):
        # 如果需要数据增强可以加在这里
        return X, Y

    def _to_tensor(self, X, Y):
        return torch.from_numpy(X), torch.from_numpy(Y)

    def __getitem__(self, idx):
        # 使用 with 语句确保每次读取后立即释放文件句柄
        with np.load(self.file_list[idx]) as data:
            X = data['IN'].astype(self.output_type)
            Y = data['OUT'].astype(self.output_type)

        # 转换为张量
        if self.use_augment:
            X, Y = self._augment_seq(X, Y)
        else:
            X, Y = self._to_tensor(X, Y)

        # 归一化 (Normalization)
        if self.normalize_x:
            X = SEVIRDataset.normalize(X, self.normalize_x)
        else:
            X = (X - self.mean) / self.std

        if self.normalize_y:
            Y = SEVIRDataset.normalize(Y, self.normalize_y)
        else:
            Y = (Y - self.mean) / self.std

        # # 维度转换 (Transform): 从原始的 (H, W, T) 转为 OpenSTL 标准的 (T, C, H, W)
        # X = X.unsqueeze(dim=0).permute(3, 0, 1, 2)
        # Y = Y.unsqueeze(dim=0).permute(3, 0, 1, 2)

        return X, Y

    @staticmethod
    def normalize(X, s):
        """
        Normalized data using s = (scale,offset) via Z = (X-offset)*scale
        """
        return (X - s[1]) * s[0]

    @staticmethod
    def unnormalize(Z, s):
        """
        Reverses the normalization performed in a SEVIRDataset generator
        given s=(scale,offset)
        """
        return Z / s[0] + s[1]


def load_data(batch_size,
              val_batch_size,
              data_root='D:/dp_projects/datasets/SEVIR/data/sevir_npz',  # 请确保这个路径指向你的 npz 根目录
              num_workers=4,
              data_name='vil',
              in_shape=[13, 1, 384, 384],
              distributed=False, use_augment=False, use_prefetcher=False, drop_last=False,
              **kwargs):
    # =========================================================
    # 分别实例化 Train 和 Test 集合
    # =========================================================
    train_set = SEVIRDataset(data_root=data_root, split='train', data_name=data_name, use_augment=use_augment)
    test_set = SEVIRDataset(data_root=data_root, split='test', data_name=data_name, use_augment=False)

    dataloader_train = create_loader(train_set,
                                     batch_size=batch_size,
                                     shuffle=True, is_training=True,
                                     pin_memory=True, drop_last=True,
                                     num_workers=num_workers,
                                     distributed=distributed,
                                     use_prefetcher=use_prefetcher)

    # 按照 OpenSTL 原有逻辑，将 test_set 同样作为验证集 (validation_set) 使用
    dataloader_vali = create_loader(test_set,
                                    batch_size=val_batch_size,
                                    shuffle=False, is_training=False,
                                    pin_memory=True, drop_last=drop_last,
                                    num_workers=num_workers,
                                    distributed=distributed, use_prefetcher=use_prefetcher)

    dataloader_test = create_loader(test_set,
                                    batch_size=val_batch_size,
                                    shuffle=False, is_training=False,
                                    pin_memory=True, drop_last=drop_last,
                                    num_workers=num_workers,
                                    distributed=distributed, use_prefetcher=use_prefetcher)

    return dataloader_train, dataloader_vali, dataloader_test


if __name__ == '__main__':
    # 你可以直接运行这个脚本来做测试，看看输入输出维度是否正确
    data_root_path = 'D:/dp_projects/datasets/SEVIR/sevir_npz/test/test_00001.npz'


    test_data = np.load(data_root_path)
    print(test_data.files)  # 看看输出的是 ['data'] 还是 ['IN', 'OUT']
    # 这里为了测试方便把 batch_size 设为 2，你可以按需修改

    # dataloader_train, dataloader_vali, dataloader_test = load_data(batch_size=2, val_batch_size=2,
    #                                                                data_root=data_root_path)
    #
    # print("\n--- 开始测试 Dataloader 数据流 ---")
    # for step, (x, y) in enumerate(dataloader_train):
    #     print(f"第 {step} 个 Batch -> X (输入) 形状: {x.shape}, Y (标签) 形状: {y.shape}")
    #
    #     # 只要打印出一个 batch 的形状正确就可以退出了
    #     break