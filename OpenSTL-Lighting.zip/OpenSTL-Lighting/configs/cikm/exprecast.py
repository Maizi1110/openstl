method = 'exprecast'
pre_seq_length = 7
aft_seq_length = 8
total_length = 15
metrics = ['mse', 'mae', 'rmse', 'csi','pod','hss','far','ssim','crps']
hid_S = 64
hid_T = 256
N_S = 4
N_T = 8
batch_size = 2
lr = 0.001
epoch = 100

